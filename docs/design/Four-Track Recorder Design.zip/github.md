repo: warmsynths/tape-tracker
branch: main
path: docs/design

## Last sync
date: 2026-11-26T12:00:00Z

### Updated in this project
- Home waveforms are bitmaps (plan D), with column counts as fallback
- Home (4.1) now has overview and focus layouts, track colours and a grid
- Removed 4.9 and 4.11 (replaced by C5 and C3)
- Added STYLEGUIDE.md and SCREENS.md for the coding agent
- Four-Track screens moved to round 5 font slots
- Round 5 C1–C11 drawn in Stock Screens.dc.html (C10, C11 rough)
- Switched to brief A font slots (14R, 17R, 14B, 17B, 12R)
- Imported stock screen references into docs/design/stock/

## Screen map
| Project screen | Repo files |
|---|---|
| Four-Track Recorder.dc.html (4.1–4.13) | docs/design/round-4-brief.md, docs/design/screen-requirements.md, docs/design/ui-constraints.md |
| Stock Screens.dc.html C1 Track mixer | docs/design/round-5-brief.md, docs/design/stock/params.png |
| Stock Screens.dc.html C2 Load samples | docs/design/round-5-brief.md, docs/design/stock/sample-load.png |
| Stock Screens.dc.html C3 Pad sample | docs/design/round-5-brief.md, docs/design/stock/sample-play.png |
| Stock Screens.dc.html C4 Resample | docs/design/round-5-brief.md, docs/design/stock/sample-rec.png |
| Stock Screens.dc.html C5 Device settings | docs/design/round-5-brief.md, docs/design/stock/config.png |
| Stock Screens.dc.html C6–C11 (sends, live filter, copy, clear, chords, sound) | docs/design/round-5-brief.md |
