# Tape Tracker UI style guide

Rules for building any screen on the device. The reference frames are `round-4-four-track-screens.html` (4.1–4.13) and `round-5-stock-screens.html` (C1–C11). Per-screen controls and the navigation map are in `SCREENS.md`. When a screen isn't drawn, build it from the parts below. Don't invent new shapes, colours or font sizes.

## 1. Canvas and budget

- Screen 800 × 480 px. Origin top left. All coordinates are integers.
- The display chip takes at most 8,172 bytes of display commands per frame (display.cpp:611). When a frame goes over, the firmware stops adding controls, so the last layers (playhead, popups) are lost first. Keep every screen under about 7.5 KB, and about 65 controls.
- Cost guide from the coding agent: a 120-column waveform is about 972 bytes; a rectangle about 20; a see-through rectangle about 32; a seven-segment digit about 18 times the same digit as text.
- Waveforms, plan D (try first): each Part's waveform is drawn once into a 1-bit bitmap in the display chip's graphics memory (600 × lane height, about 6.3 KB per 84 px lane), uploaded only when the Part changes (end of a take, after an edit). Each frame draws it with one bitmap command in the track colour (about 12 bytes). Detail is 1 px per column. The playhead split stays one see-through overlay. Needs: an upload call, a bitmap-draw command, the extended size setting for bitmaps wider than 511 px, and a check of where free graphics memory starts (above the stock images and fonts).
- Waveforms, plan A (fallback if the chip refuses D on the device): 120 columns at 5 px pitch (4 px bar) for the lane in focus, the Part Editor and the stock sample screens (100 if a frame is still over); 60 at 10 px (8 px bar) in the home overview; 30 at 20 px (16 px bar) in a home strip. Optionally merge neighbouring columns of the same rounded height into one wider rectangle; it saves 20–50% but can't be counted on.
- Rectangle columns cost about 8 bytes each whatever their height. Lane height is free; column count is not.
- Primitives only: text, filled rectangle, outlined rectangle (1 px), filled circle (Rec only). No icons except Play (▶, 17 bold) and drawn shapes.
- See-through (alpha) rectangles are allowed for tints and shades. Set the alpha, draw, then restore full opacity straight away so it never leaks into the next control.
- No fades, slides, scrolling animation or zoom. Allowed motion: playheads, meters, a moving highlight, changing numbers. Changing numbers have fixed-width boxes so nothing shifts.

## 2. Screen zones

| Zone | y | Height | Contents |
|---|---|---|---|
| Top bar | 0 | 32 | Fill `top`, 1 px `frame` line at y 31 |
| Content | 32 | 368 | Screen body |
| Hint line | 400 | 40 | 1 px `frame` line at y 400, one line of 14 regular at x 14, y 411–412 |
| Button strip | 440 | 40 | Fill `frame`, eight cells |

Some screens use a help block instead of a hint line: a 1 px rule at y 376, title in 17 bold at y 386, one line of 14 regular at y 410 (Device settings, Four-Track settings).

## 3. Top bar (same on every screen)

Left to right, separated by 1 × 16 px `frame` dividers at y 8:
- Project name, 17 bold, `topText`, x 12, 110 px box. Unsaved mark: 6 × 6 `warn` square at x 124, y 13.
- `BPM` caption (12 regular, `dim`) + tempo (17 bold) · `BARS` + bars · `POS` + bar.beat.tick · `IN` + source (14 regular).
- Tags from x 540: `MON` (filled `topText`) or `MON OFF` (outlined `dim`). Then, when they apply: `FB −6 dB` (filled `warn`), `FILTER` (filled `meter`, live filter latched). A tag shown here is visible on every screen.

## 4. Button strip

- Eight cells, 97 × 39 px on a 100 px pitch, x = i × 100 + 1, y 441. Gaps show the `frame` fill.
- Label: 14 regular, centred, `text`. 9–10 characters at most. Empty cells keep their fill and have no label.
- On or active: cell fill `sel` plus a 2 px `text` line at the top of the cell.
- Unavailable: label in `dim`. The cell is still drawn.
- Rec: 10 px `rec` circle at x + 16, y 455, label at x + 34. Stop: 10 px `text` square in the same place.
- Red label (`rec`): only for record and for Clear / Clear all.
- B8 is Back (or Done, Close, Cancel on popups) wherever a screen can be left. In a popup, B7 is Cancel and B8 confirms.

## 5. Font slots (exactly five)

| Slot | Use |
|---|---|
| 17 bold | Project name, top-bar values, screen titles, track names, field values, popup titles, help title, Play glyph |
| 17 regular | Second readout of the same value (fine tune in cents, ms for a note value, bars for an offset, percent) |
| 14 bold | Focused row in a list, previewed or chosen item name |
| 14 regular | Button labels, list rows, hint and help lines, popup body, M and S letters |
| 12 regular | Captions above values, column heads, units, tags, secondary lines |

Line height is the font size + 4. Text is never wrapped: give every text a fixed box width and write copy that fits.

## 6. Colour roles

Always use the role name, never a hex value, so a theme can recolour everything.

| Role | Original | Mono | Use |
|---|---|---|---|
| bg | #15130f | #000000 | Screen ground |
| top | #221f19 | #000000 | Top bar |
| topText | #d3c8ae | #ffffff | Top-bar text |
| frame | #3a342a | #7f7f7f | Hairlines, button strip, column edges, popup edge |
| text | #e6dcc3 | #ffffff | Primary text, playhead, faders and value bars, focus line |
| dim | #91876f | #8a8a8a | Captions, outlined tags, off and unavailable states |
| cell | #211e18 | #000000 | Button cells, unselected choice cells |
| sel | #332e25 | #262626 | Selected track, field, row, group, cell |
| panel | #1c1a15 | #000000 | Track headers, field cards, side panels, popups |
| rec | #c4452e | #ffffff | Record only (+ Clear buttons) |
| meter | #93a66a | #ffffff | Level meters, ON / GLT / SAVED / FILTER tags |
| track | #2c2922 | #3a3a3a | Backgrounds of meters, faders and bars |
| wave | #8d826c | #7f7f7f | Waveform |
| waveBg | #191712 | #000000 | Waveform area |
| waveOff | #575043 | #4a4a4a | Trimmed or muted audio, bars of off controls |
| marker | #d8873a | #ffffff | Loop line, Start/End and trim markers, Mute on |
| warn | #d2a94f | #ffffff | Memory warnings, REPLACES, unsaved mark, bypass, feedback |
| t1 | #d0a35a | #ffffff | Track 1 colour |
| t2 | #7fa996 | #ffffff | Track 2 colour |
| t3 | #8e9fc6 | #ffffff | Track 3 colour |
| t4 | #b394c2 | #ffffff | Track 4 colour |

Track colours go on the track number, the header edge, the level meter and the waveform, on every screen that shows a track. Tints are the track colour as a see-through rectangle: 10% on the lane and header, 22% on the selected header. The waveform ahead of the playhead is darkened by one black rectangle at 58%; a muted lane by one at 60%. Never store shades as extra colours.

Every state must still read in Monochrome: use filled against outlined, the `sel` fill with its 2 px line, or words. Never colour alone.

## 7. Parts

**Selection and focus**
- Selected item in a vertical list or a track: `sel` fill + 4 px `text` bar on the left edge.
- Focused field, row or card that the jog changes: `sel` fill + 2 px `text` line along the top.
- When focus moves between a list and its rows (Device settings), the list keeps its `sel` fill and only the focused side gets the 4 px bar or 2 px line.

**List row**: 32 px tall on a 34 px pitch. Name at x + 16 (or 24 in full-width lists), 14 regular, 14 bold when focused. Value columns in 14 regular. Folders: an outlined 12 × 9 px box before the name.

**Settings row**: 32 px on 34 px. Name 14 regular at x + 16; value 17 bold at a fixed value column. Group headings: 12 regular `dim` with a 1 px `frame` rule.

**Field card**: 254 × 68 px on a 258 px pitch, three per row, x from 14. Caption 12 regular at +10, value 17 bold at +28, optional second readout 17 regular on the same line, optional sub line 12 regular at +50. Fill `panel`, focused `sel` + 2 px line.

**Choice cell**: 97 px wide on a 100 px pitch (or 110/144 px inside panels). Label centred or at +10/+12. Chosen: `sel` + 2 px line. Unavailable: label `dim`.

**Tag**: 18 px tall, width = characters × 7 + 12, 12 regular centred. Filled = active state (text in `bg`). Outlined 1 px = passive or off (text in the border colour).

**M / S box**: 20 × 20, 14 regular letter. Off: outlined `dim`. Mute on: filled `marker`. Solo on: filled `text`.

**Value bar**: 4–6 px tall on `track`. Fill `text` when on, `waveOff` when off. A centre mark (1 × 16 `dim`) for bipolar values (pan, tone, sweep). Position marker 3 × 16 `text` or `marker`.

**Meter**: 3–10 px on `track`, fill `meter` (`rec` while recording). Optional 1 px `dim` tick at −6 dB or 0 dB.

**Vertical fader**: 16 px wide on `track`, filled from the bottom, a 1 px `dim` tick at 0 dB, live meter 6 px wide beside it.

**Waveform**: `waveBg` area, columns in `wave`. Audio outside Start/End or trimmed off in `waveOff`. Markers are 1 px full-height `marker` lines. Loop region: 3 px `marker` line along the top. Playhead: 1 px `text` line (7 × 4 cap on home).

**Popup**: 500 px wide panel at x 150, centred vertically in the content zone. Fill `panel`, 1 px `frame` edge, 2 px `text` line on top. Title 17 bold at +20 (optional filled tag or Rec circle before it). Body lines 14 regular on a 20 px pitch from +56. Detail lines 12 regular `dim` on a 16 px pitch. No scrim; the screen below stays drawn. Buttons B7 Cancel, B8 confirm.

**Bottom panel** (How many bars, Starting tempo): full width, `panel` fill, 1 px `frame` + 2 px `text` line on top, title 17 bold at +14.

**Columns**: four tracks = four 200 px columns with 1 px `frame` dividers. Two blocks = two 400 px halves. Side panel or list = 200 px (groups) or 480 px (files) with a 1 px divider.

## 8. Home layouts

- **Overview**: four 84 px lanes on an 86 px pitch from y 56, 60-column waveforms. Shown when stopped, playing, and on the empty project.
- **Focus**: one lane at 250 px with 120 columns; the other three are 28 px strips on a 30 px pitch, in track order (they never move). A strip has the number (17 bold, track colour), name (14 regular), M, a 30-column outline and the playhead.
- Focus opens on arming, on the first take, and when the selected Track button is pressed again. It closes when the take ends, on Stop, or on the Track button again. The switch is instant.
- Grid: bar lines (text at 22%) and beat lines (text at 8%) are one see-through 1 px rectangle each, drawn once over all four lanes. In focus, 16th ticks are added to the ruler only. Draw nothing per lane per line.
- The ruler highlight (sel fill) steps every beat in the overview and every 16th in focus. The current bar number is drawn in text, the others in dim.
- No seven-segment counter: POS in the top bar is the counter.

## 9. Controls (same meaning everywhere)

- Up/Down: move between rows or controls. Left/Right: move between columns, tracks, blocks, or between a list and its rows.
- Jog turn: change the focused value (or scroll a long list). Shift + jog: fine steps.
- Jog press: open or toggle the focused item, only where a screen says so.
- B1–B4: actions for the screen. B5–B8 on home: Track 1–4. B8 elsewhere: Back.
- Shift + button: allowed, but **every Shift combination must be named on screen** in that screen's hint line, help line, a caption, or the popup it belongs to. No hidden shortcuts.
- Hint line copy says what the next press does, in plain words: `Shift + B3: reset all tracks.`
- Undo: one step for the whole project (the last copy, clear or Part edit). Shift + Copy anywhere, B3 Undo in the Part Editor. Every undoable action names this in its popup or hint.

## 10. States to draw for every screen

Default; focused field; any on/active state; empty (nothing loaded, no Part); error (SD card missing, memory full); in progress (writing, recording, updating). Errors use a popup, or `warn` text in the hint line with the affected control shown `dim`. Home has two layouts (section 8): draw each state in the one it uses.

## 11. Copy

- Sentence case. Short and literal: `Track 3 cleared. Shift + Copy brings it back.`
- Name things the same way on every screen: Part, Loop, Track 1–4, slot 1–48, Pads, Keys, Pad.
- Units always shown: dB, ms, s, Hz, kHz, %, BPM, st, ct.
- Tags in capitals: LINE, MIC, PAD, GLT, MON, ON, OFF, KEYS, READY, RECORDING, SAVED, MEMORY FULL, REPLACES, FILTER.

## 12. Adding a new settings row or screen

1. Put it in the closest existing pattern: settings row, field card, list or popup.
2. Use only the roles and slots above.
3. Add one help or hint line explaining it, and name any Shift combination.
4. Estimate the display bytes with the cost guide in section 1; stay under about 7.5 KB.
