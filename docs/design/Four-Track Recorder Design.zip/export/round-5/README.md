# Round 5 design output

Open either HTML file in a browser. Both are self-contained and work offline.

- `round-5-stock-screens.html`: C1 to C11 (Track mixer, Load samples, Pad sample settings, Resample, Device settings, Reverb and delay, Live filter, Copy, Clear, and rough Chords and Sound). Each screen has frames per state, a control table, and notes on colour roles and font slots. The end of the page lists what was dropped and which controls are proposed.
- `SCREENS.md`: navigation map, undo, and every screen's frames, controls and notes.
- `STYLEGUIDE.md`: rules for the coding agent: zones, font slots, colour roles, parts, controls, copy.
- `round-4-four-track-screens.html`: Four-Track screens 4.1 to 4.13, including the home overview and focus layouts, track colours and bitmap waveforms.


Exact coordinates: each screen is drawn by one function in the HTML source (search for the `<script type="text/x-dc">` block). The coding agent can lift positions straight from it.
