# STYLEGUIDE · Four-Track Recorder, round 6

The page `Four-Track Recorder.dc.html` is the source of truth; frame 0 shows every component in its states. One drawing engine applies these rules to every screen (4.x Four-Track, 6.x chords and synth, C1–C9 stock).

## Display and budget
- 800 × 480. Eight buttons under the screen: 97 px cells on a 100 px pitch.
- 8,172 bytes of display commands per frame; aim under 7 KB. Costs: rectangle 20, rounded rectangle 20, line 20, circle 24, colour change 4, transparency change 4, text 16 + 4 to 8 per character, bitmap 40.

## Shape
- One corner radius, 6 px, on every card, field, button cell, tag, M box, pad fill and lane card: anything at least 18 × 18 px.
- Full-width bands stay square: top bar, ruler, hint line, list rows, the button strip behind the cells.
- Circles only for the Rec mark and lamps. Lines only for hairlines, bar lines, the playhead and markers.
- Outlines only for: outlined tags, M off, Hold off, popups.

## Fills, focus and choice
- A fill means pressed, chosen or focused. Nothing else gets a box; content sits on the ground as type.
- **Focus** (where the jog acts): sel fill plus a 2 px text-colour line along the top, inset 8 px from the corners. On a full-width list row the same line runs along the top of the row.
- **Chosen** (the current option in a set): sel fill and a bold label, no line.
- **Held** pad: solid fill (chord family colour for chords, text colour for notes and play pads), label in bg.
- **Latched**: sel fill and an orange bold label (modifiers), or an orange fill (Hold).
- Buttons: cell; on = sel fill and a short cream pill at the top.

## Colour roles
- bg, top, topText, frame, text, dim, cell, sel, panel, rec, meter, track, wave, waveBg, waveOff, marker, warn, t1–t4.
- **Tracks** keep hue (t1–t4) on two things only: the track number, and a 3 px edge inside the header when selected. The selected track also has the sel header and a cream waveform; others are wave. The Play view mutes track hue.
- **Chord families** use the same hues, only on the chord pads: Home (I, iii, vi) t1, Away (ii, IV) t2, Tension (V, vii°) t3. The family belongs to the chord root; modifiers never change it.
- **Red** (rec) is record only. **Orange** (marker) is a changed value, a latched control, the Loop region and markers; it never marks the tonic. **Green** (meter) is levels and ON. **Yellow** (warn) is memory, feedback and unsaved.
- Monochrome: t1–t3 become white, light grey and mid grey so the families still separate.

## Drawing
- Levels are green bars, never dials. Amounts (sends, depth, gain) are dim bars.
- Every waveform is a 1-bit bitmap at one column per pixel, drawn once per Part, including the take being recorded and the Part Editor.
- Ahead of the playhead the lane is darkened by one see-through rectangle; a muted lane by a second one.

## Type
- 17 Bold: titles, values, chord names up to 4 characters, track names.
- 17 Regular: note names, modifier names, secondary readouts.
- 14 Bold: longer chord names, the chosen style, focused or held labels.
- 14 Regular: button labels, the hint line, lists, labels.
- 12 Regular: captions, tags, units, ruler numbers.
- No arrows or symbols beyond − · ° … ; names are written out (Strum dn, Arp up).

## Chord pads (6.1, 6.4)
- Left hand, columns 1–8: row 1 sevenths I–vii and I, row 2 triads, rows 3–4 scale notes (C pads show C3, C4, C5).
- Right hand, columns 9–12: rows 1–2 modifiers (sus2 sus4 6 7 / maj7 add9 9 flip; hold to apply, double-tap to latch), rows 3–4 Block, Strum dn, Strum up, Arp up / Arp dn, Oct −, Oct +, Hold.
- While a modifier is held, every chord name changes to what it will play. A note outside the key is named under the chord (C#, F#).
- LED brightness: held pad, held or latched modifier, chosen style 100%; in-key chords 40%; other modifiers and styles 25%.

## Words
- Track, Part, Loop, Loop Mode, Offset. Hint line: one sentence. Recording limit: 16 s per Part.
